# Auxiliary Vision Model Deprecation — Reference (May 2026)

## The Problem

Google periodically removes deprecated Gemini models from the API. When `vision_analyze` uses a deprecated model, you get:

```
Gemini HTTP 404 (NOT_FOUND): This model models/gemini-2.0-flash is no longer available to new users.
```

This affects `auxiliary.vision.model` in `config.yaml`. The model is used by `vision_analyze` and the gateway's image pre-processing pipeline.

## Diagnosis

```bash
# Check what model is configured
grep -A3 "auxiliary:" ~/.hermes/config.yaml | grep vision -A2

# Check agent logs for the 404 error
grep "NOT_FOUND" ~/.hermes/logs/agent.log | tail -5

# Check model catalog (cached at ~/.hermes/hermes-agent/model_catalog.json)
cat ~/.hermes/hermes-agent/model_catalog.json 2>/dev/null | python3 -c "
import sys, json
d = json.load(sys.stdin)
for p, data in d.get('providers', {}).items():
():
    for m in data.get('models', []):
        if 'gemini' in m.get('id', '').lower() and 'vision' in m.get('description', '').lower():
            print(p, m['id'], m.get('description', ''))
" 2>/dev/null || echo "Catalog not locally cached"
```

## Available Replacement Models

From `https://hermes-agent.nousresearch.com/docs/api/model-catalog.json` (May 2026):

### Gemini family (recommended — same provider)
| Model ID | Status | Notes |
|----------|--------|-------|
| `google/gemini-3-flash-preview` | ✅ Working | Latest stable, use as default |
| `google/gemini-3-pro-preview` | ✅ Working | Higher capability, higher cost |
| `google/gemini-3.1-pro-preview` | ✅ Working | |
| `google/gemini-3.1-flash-lite-preview` | ✅ Working | Budget option |
| `google/gemini-3.5-flash-preview` | 🔜 Replacing gemini-2.5-flash (Oct 2026 shutdown) | Already in flight (#32360) |

### OpenAI (alternative provider)
| Model ID | Provider | Notes |
|----------|----------|-------|
| `openai/gpt-4o-mini` | openai | Budget vision, works with `OPENAI_API_KEY` |
| `openai/gpt-4o` | openai | Higher quality |

### Anthropic (alternative provider)
| Model ID | Provider | Notes |
|----------|----------|-------|
| `anthropic/claude-haiku-4.5` | anthropic | Budget vision option |
| `anthropic/claude-sonnet-4.6` | anthropic | Higher capability |

## Fix Applied to Master KT's Config

```yaml
# ~/.hermes/config.yaml — BEFORE (broken)
auxiliary:
  vision:
    provider: gemini
    model: gemini-2.0-flash

# AFTER (working)
auxiliary:
  vision:
    provider: gemini
    model: gemini-3-flash-preview
```

Apply with:
```bash
hermes config set auxiliary.vision.model gemini-3-flash-preview
```

Restart the gateway or start a new CLI session for the change to take effect.

## Related GitHub Issues (May 26, 2026)

- **#32296** — `vision_analyze` retries non-retryable 4xx (404/403) 3x with backoff — fix in flight
- **#32160** — Feature request: automatic vision fallback to auxiliary model when primary lacks vision
- **#32360** — Fix: update default Gemini model from gemini-2.5-flash to gemini-3.5-flash (shutdown Oct 16 2026)

## Pattern: Model Deprecation in Auxiliary Providers

Auxiliary tasks (vision, compression, web_extract, triage_specifier, etc.) use their own `provider` + `model` under `auxiliary.*`. When these fail, the first question is always: **is the configured model still available?** Check:

1. The model catalog at `https://hermes-agent.nousresearch.com/docs/api/model-catalog.json`
2. The provider's own documentation for model lifecycle dates
3. GitHub issues for the hermes-agent repo (`is:issue gemini deprecate`, `is:issue vision model`)

The fix is always the same pattern: update `auxiliary.<task>.model` to a current model, or switch the `auxiliary.<task>.provider` to one that has the current model.