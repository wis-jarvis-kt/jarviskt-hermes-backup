# Disk Space Watchdog — Script Reference

**Path:** `~/.hermes/scripts/disk_space_watchdog.sh`
**Schedule:** every 24h (cron job `99ed63eabd51`)
**Platform:** macOS (Darwin); also runs on Linux

## Purpose

Auto-cleanup when free disk drops below 50GB. Cleans:
- Old cron output dirs (`~/.hermes/cron/output/*/`, aged >7 days)
- Old session files (`~/.hermes/sessions/session_*`, aged >7 days)
- Old daily memory logs (`research-*`, `war-news-*`, `stock-radar-*`, `victor-study-*`, aged >7 days)
- Old Hermes log files (`~/.hermes/logs/*.log`, aged >7 days)
- macOS sleepimage if >1GB

## Bug Fixed 2026-06-13

The memory log cleanup had broken find logic:

```bash
# BROKEN — the -o chain with -name "*.log" was problematic
DELETED_MEM=$(find "$MEMORIES" -name "research-*" -o -name "war-news-*" \
  -o -name "stock-radar-*" -o -name "victor-study-*" -o -name "*.log" 2>/dev/null \
  | xargs -I{} find {} -mtime +${DAYSOLD} -type f 2>/dev/null | wc -l | tr -d ' ')
```

`-name "*.log"` matched nothing (no `.log` files directly in `~/.hermes/memories/`), so `xargs` received zero paths and the inner find never ran. Count was always 0, no files ever deleted.

**Fixed:**

```bash
DELETED_MEM=$(find "$MEMORIES" \( -name "research-*" -o -name "war-news-*" \
  -o -name "stock-radar-*" -o -name "victor-study-*" \) -type f \
  -mtime +${DAYSOLD} -delete 2>/dev/null | wc -l | tr -d ' ')
```

Key fixes:
- Group `-name` patterns with `\ ( ... -o ... \ )` so `-mtime` and `-type f` apply to all
- `-type f` before `-mtime` (correct argument order)
- `-delete` in-process instead of piping to `xargs find`
- Removed the dead `-name "*.log"` branch

## macOS df column Parsing

```bash
if [ "$(uname)" = "Darwin" ]; then
  AVAILABLE_GB=$(df -g / | tail -1 | awk '{print $4}')  # col 4 = Available on macOS
else
  AVAILABLE_GB=$(df -BG / | tail -1 | awk '{print $4}' | tr -d 'G')
fi
```

On macOS `df -g`, the output columns are: Filesystem, 1K-blocks, Used, Available, Capacity, iused, ifree. **Column 4 = Available**, not column 7. This was already correct in the script but is a common macOS `df` pitfall.
