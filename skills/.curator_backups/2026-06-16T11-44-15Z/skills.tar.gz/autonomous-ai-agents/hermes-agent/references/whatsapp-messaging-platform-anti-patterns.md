# WhatsApp (and Messaging Platforms) — Anti-Patterns & User Preferences

## Master KT's Non-Negotiable Communication Style

**Outcome-only responses.** No working steps, no tool outputs, no process, no explanations, no "Done." confirmation. Just the result.

Example:
- **Right:** "Tang Shen Yao added at 8:30 PM."
- **Wrong:** "Running terminal command... Result: {...} ... Done."

## Why Tool Outputs Appear in WhatsApp

WhatsApp (and other messaging platforms) use auto-delivery. The cron job's final response — including ALL tool results appended to it — gets sent to the home channel. This means:

1. Every tool call (`terminal`, `cronjob`, `send_message`, etc.) appends its raw JSON output to the response
2. Auto-delivery packages the entire response — tool results included — and sends it
3. Master KT sees the raw tool output, cron job metadata, JSON blobs

## The Fix

**For every WhatsApp interaction:** The final text response (what the user sees) should be ONLY the human-readable outcome. Strip all tool results from the response before it gets auto-delivered.

Practically:
- When using `terminal` to run a command → parse the result in the same tool call, derive the one-line outcome, and put ONLY that in the response
- When using `cronjob` → same: parse the job ID/time from the result, don't include the raw JSON
- Do NOT include: tool return payloads, JSON blobs, cron job metadata, "Done.", "Reminder set.", etc.
- Do NOT say "Done." — the outcome itself is confirmation enough

## Group Chat Behavior

- Stay silent unless @mentioned
- Config: `whatsapp.require_mention: true` in `config.yaml`

## Sending Images/Media to WhatsApp

**`MEDIA:` tags don't work on WhatsApp.** The bridge does not support local file attachment via `MEDIA:` path in `send_message`. Attempting this returns: `media attachments are not supported for this target`.

**Workaround — upload to tmpfiles.org, then send the URL:**
```python
import requests
with open('/path/to/image.png', 'rb') as f:
    r = requests.post('https://tmpfiles.org/api/v1/upload', files={'file': f}, timeout=30)
url = r.json()['data']['url']   # → https://tmpfiles.org/xxx/image.png
# Then send as text
send_message(target='whatsapp:Goo Kah Thart', message=url)
```

**Phone number targets fail.** `whatsapp:+60125226892` produces: `Cannot destructure property 'user' of 'jidDecode(...)' as it is undefined`.

**Use contact name from `send_message(action='list')` instead.**

## What NOT to Show in WhatsApp

- Cron job JSON responses (`{"success": true, "job_id": "...", ...}`)
- Calendar event creation JSON (`{"status": "created", "id": "...", ...}`)
- Terminal command outputs (JSON, table prints)
- "Done.", "Reminder set.", "Added.", etc.
- Any tool's raw return value

## The Only Exceptions

If there's a real issue (error, failure, uncertainty), state it plainly in plain text. No need to show the raw error — describe it in one sentence and ask if Master KT wants to proceed.

## Cron Job Reminders — Always Silent Until Fired

When Master KT says "remind me X next Wednesday" — create the cron job silently. Do not confirm with "Reminder set." Just execute and stay quiet unless there's a problem.