---
name: research-scout
description: "Recurring evening AI/tech research scout: find 3 notable developments, save to ~/.hermes/memories/research-YYYY-MM-DD.md. For one-shot or ad-hoc research, prefer delegate_task subagents with the `web` toolset."
version: 1.0.0
---

# Research Scout

Run a recurring evening scan of AI/tech developments and save a brief report to `~/.hermes/memories/research-YYYY-MM-DD.md`.

## Workflow

1. **Navigate** to `https://www.artificialintelligence-news.com/` — loads reliably in cron jobs (no anti-bot blocking observed).
2. **Accept cookie consent** if dialog appears: `browser_click(ref=e3)` on "Accept".
3. **Scan headlines** for 3 notable AI/tech developments. Prioritise articles with today's date. **Click the article heading link** — heading-click anti-bot is intermittent (~67% success rate), so proceed to the next article if it fails; use direct URL as rescue only.
4. **Verify page title after each navigation** — if the title doesn't match the expected article, the link may have been redirected by anti-bot protection. Use Google News search as fallback.
5. **Read each article** via `browser_snapshot(full=false)` — compact snapshot is sufficient for article reading; use full=true only if compact returns suspiciously little content. Capture title, source date, key points, and "why it matters" takeaway.
6. **If fewer than 3 articles with today's date appear on the homepage**, scroll down the "LATEST" section. If still insufficient, use Google News search (`https://news.google.com/search?q=AI+technology&hl=en-US&gl=US&ceid=US:en`) to find supplementary stories — **click through to the original source publication's native domain** (TechCrunch, blog.google, Reuters, etc.), not the aggregator link. Prioritise developments that are genuinely new (not dated several days prior) even if the primary source is not the AI News homepage.
7. **Write findings** to `~/.hermes/memories/research-YYYY-MM-DD.md` with frontmatter header:

```markdown
# AI/Tech Research Scout — YYYY-MM-DD

## Evening Scan: 3 Notable Developments

---

### 1. [Headline]

**Source:** ... — YYYY-MM-DD  
**Category:** ...

**Summary:**  
...

**Key points:**
- ...

**Why it matters:** ...
```

8. **Verify the file** by reading back the first few lines (check line count and last entry's "Why it matters" is present).

## Verified Working Sources (cron job context)

| Source | URL | Notes |
|---|---|---|
| AI News | `https://www.artificialintelligence-news.com/` | Reliable, no anti-bot. Accept cookie dialog first. |
| Google News Search | `https://news.google.com/search?q=QUERY&hl=en-US&gl=US&ceid=US:en` | Lightweight, rarely blocked. |

## Anti-Bot Patterns to Avoid

- **Google News RSS** (`news.google.com/rss/search?q=...`) — returns zero `<item>` elements in cron job context. Use browser navigation instead.
- **Google News direct article URLs from AI News listing** — can redirect unexpectedly to an empty page or a different article on the same domain. Always verify page title after navigation; if wrong, fall back to Google News search for the original source publication.
- **Bing.com** — triggers Cloudflare human verification in cron jobs.
- **Major news sites via Google News click path** — NYT, CNBC, Reuters, and others block via DataDome or Cloudflare when the click path routes through Google News. Reuters via Google News is a *confirmed hard block* — do not retry. Navigate directly to the article's native domain or find a different outlet's link in Google News results.
- **AI News article heading link clicks — intermittent anti-bot (~67% success on featured section)** — links in the "LATEST" section appear to have a higher block rate. Prioritise the top 2–3 featured article headings (large cards) before scrolling to LATEST. **Do NOT abandon heading clicks entirely** — proceed to the next article if it fails; use direct URL as rescue only.
- **`(empty page)` on snapshot after click** — if `browser_snapshot(full=false)` returns `(empty page)` with `element_count: 0`, the link triggered an anti-bot redirect. **Do NOT immediately use direct URL** — proceed to the next article on the listing; use direct URL rescue only if you need to recover that specific article. On returning to the homepage, the heading links get fresh ref IDs — re-identify and click the next article's link.
- **Money Morning** — anti-bot blocked via Google News click path. Treat like Reuters. Use direct navigation instead.
- **TechCrunch, NVIDIA Newsroom, PCMag Australia, Mashable** — accessible via Google News click path; no blocking observed.
- **Silent interception on AI News heading clicks** — the click is consumed without raising an error, ref IDs on the page refresh (new page context), but `browser_snapshot` still shows the homepage content. This is a distinct failure mode from the empty-page redirect. Both are resolved by navigating directly to the original source domain.

## Rescue Pattern (Anti-Bot Block After Click)

```
1. browser_snapshot(full=false) → element_count: 0 OR homepage content (refs match listing page)
2. Do NOT retry the click or use browser_back()
3. Navigate directly to the original source domain (TechCrunch, blogs.nvidia.com, etc.)
   OR search Google News for the article title and click a different outlet's link
4. browser_snapshot(full=false) to verify correct article loaded
5. Proceed with reading
```

## Save Format

Use this exact header format so future agents can parse it:

```
# AI/Tech Research Scout — {date}

## Evening Scan: 3 Notable Developments
```

Each entry must include: source + date, category, summary, key points, and "why it matters."

## Support Files

- `references/anti-bot-patterns-session-log.md` — session-tested anti-bot patterns, URL workarounds, and rescue flow. Updated after each scout run that encounters blocking.

## Related Skills

- `web-research-limitations` — anti-bot patterns, delegate_task subagent workflow for multi-sector research
- `arxiv` — academic paper discovery
- `polymarket` — market-sentiment research
- `blogwatcher` — recurring blog/RSS monitoring